﻿namespace Items.DataAccess
{
    public class Class1
    {

    }
}
